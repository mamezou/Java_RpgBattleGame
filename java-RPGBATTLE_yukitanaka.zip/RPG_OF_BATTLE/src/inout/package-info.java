/**
 * 
 */
/**
 * @author mamezou
 *
 */
package inout;